# React Basic Guide

```
> npm install
> npm start
```
