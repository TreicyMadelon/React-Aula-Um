import React,{ Component} from 'react';

class FirstCompo extends Component {
    
    render(){
        return (
        <div>
                <h1>React Testing</h1>
        </div>
        );
    }
}

export default FirstCompo;